# Upute za pokretanje projekta

1. Instalirati Node.js s adrese:

   https://nodejs.org/en

2. Preuzeti projekt s GitHub repozitorija.

3. Otvoriti CMD (Command Prompt) ili PowerShell u mapi projekta.

4. Instalirati potrebne pakete naredbom:

   npm install

5. Pokrenuti aplikaciju naredbom:

   node server.js

6. U internetskom pregledniku otvoriti:

   http://localhost:3000

7. Aplikacija je spremna za korištenje.
